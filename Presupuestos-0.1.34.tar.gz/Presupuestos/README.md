Programa para realizar presupuestos de obra, trabajos, materiales, etc.

Ayuda, videos de uso en la página web del proyecto:
http://presupuestosobras.blogspot.com/
